-- phpMyAdmin SQL Dump
-- version 3.3.7deb7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 31, 2012 at 11:22 PM
-- Server version: 5.0.51
-- PHP Version: 5.3.3-7+squeeze8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `vpanel_empty`
--

-- --------------------------------------------------------

--
-- Table structure for table `beitraege`
--

CREATE TABLE IF NOT EXISTS `beitraege` (
  `beitragid` int(11) unsigned NOT NULL auto_increment,
  `label` varchar(50) NOT NULL,
  `hoehe` double default NULL,
  `mailtemplateid` int(10) unsigned default NULL,
  PRIMARY KEY  (`beitragid`),
  UNIQUE KEY `label` (`label`),
  KEY `mailtemplateid` (`mailtemplateid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `beitraege`
--

INSERT INTO `beitraege` (`beitragid`, `label`, `hoehe`, `mailtemplateid`) VALUES
(1, '2012', NULL, 1),
(2, 'Camp 2011', NULL, 1);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `beitraege`
--
ALTER TABLE `beitraege`
  ADD CONSTRAINT `beitraege_ibfk_1` FOREIGN KEY (`mailtemplateid`) REFERENCES `mailtemplates` (`templateid`);
