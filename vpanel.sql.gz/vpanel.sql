-- phpMyAdmin SQL Dump
-- version 2.11.8.1deb5+lenny6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 24, 2010 at 10:43 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6-1+lenny9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `vpanel`
--

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE IF NOT EXISTS `countries` (
  `countryid` int(10) unsigned NOT NULL auto_increment,
  `label` varchar(20) NOT NULL,
  PRIMARY KEY  (`countryid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`countryid`, `label`) VALUES
(1, 'Deutschland');

-- --------------------------------------------------------

--
-- Table structure for table `gliederungen`
--

CREATE TABLE IF NOT EXISTS `gliederungen` (
  `gliederungsid` int(10) unsigned NOT NULL auto_increment,
  `label` varchar(30) NOT NULL,
  PRIMARY KEY  (`gliederungsid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `gliederungen`
--

INSERT INTO `gliederungen` (`gliederungsid`, `label`) VALUES
(1, 'Bundesverband');

-- --------------------------------------------------------

--
-- Table structure for table `jurperson`
--

CREATE TABLE IF NOT EXISTS `jurperson` (
  `jurpersonid` int(10) unsigned NOT NULL auto_increment,
  `label` varchar(35) NOT NULL,
  PRIMARY KEY  (`jurpersonid`),
  UNIQUE KEY `label` (`label`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jurperson`
--


-- --------------------------------------------------------

--
-- Table structure for table `kontakte`
--

CREATE TABLE IF NOT EXISTS `kontakte` (
  `kontaktid` int(10) unsigned NOT NULL auto_increment,
  `strasse` varchar(40) NOT NULL,
  `hausnummer` varchar(5) NOT NULL,
  `ortid` int(10) unsigned NOT NULL,
  `telefonnummer` varchar(15) NOT NULL,
  `handynummer` varchar(15) NOT NULL,
  `email` varchar(50) NOT NULL,
  PRIMARY KEY  (`kontaktid`),
  KEY `ortid` (`ortid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `kontakte`
--

INSERT INTO `kontakte` (`kontaktid`, `strasse`, `hausnummer`, `ortid`, `telefonnummer`, `handynummer`, `email`) VALUES
(1, 'Test', '13', 1, '1234567', '7654321', 'test@trolololo.com');

-- --------------------------------------------------------

--
-- Table structure for table `mailattachments`
--

CREATE TABLE IF NOT EXISTS `mailattachments` (
  `attachmentid` int(10) unsigned NOT NULL auto_increment,
  `filename` varchar(25) NOT NULL,
  `mimetype` varchar(15) NOT NULL,
  `content` blob NOT NULL,
  PRIMARY KEY  (`attachmentid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mailattachments`
--


-- --------------------------------------------------------

--
-- Table structure for table `mailheaders`
--

CREATE TABLE IF NOT EXISTS `mailheaders` (
  `headerid` int(10) unsigned NOT NULL auto_increment,
  `label` varchar(15) NOT NULL,
  PRIMARY KEY  (`headerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mailheaders`
--


-- --------------------------------------------------------

--
-- Table structure for table `mailtemplateattachments`
--

CREATE TABLE IF NOT EXISTS `mailtemplateattachments` (
  `templateid` int(10) unsigned NOT NULL,
  `attachmentid` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`templateid`,`attachmentid`),
  KEY `attachmentid` (`attachmentid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mailtemplateattachments`
--


-- --------------------------------------------------------

--
-- Table structure for table `mailtemplateheaders`
--

CREATE TABLE IF NOT EXISTS `mailtemplateheaders` (
  `templateid` int(10) unsigned NOT NULL,
  `headerid` int(10) unsigned NOT NULL,
  `value` varchar(30) NOT NULL,
  PRIMARY KEY  (`templateid`,`headerid`),
  KEY `headerid` (`headerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mailtemplateheaders`
--


-- --------------------------------------------------------

--
-- Table structure for table `mailtemplates`
--

CREATE TABLE IF NOT EXISTS `mailtemplates` (
  `templateid` int(10) unsigned NOT NULL auto_increment,
  `body` text NOT NULL,
  PRIMARY KEY  (`templateid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mailtemplates`
--


-- --------------------------------------------------------

--
-- Table structure for table `mitglieder`
--

CREATE TABLE IF NOT EXISTS `mitglieder` (
  `mitgliedid` int(10) unsigned NOT NULL auto_increment,
  `globalid` varchar(50) NOT NULL,
  `eintritt` date NOT NULL,
  `austritt` date default NULL,
  PRIMARY KEY  (`mitgliedid`),
  UNIQUE KEY `globalid` (`globalid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `mitglieder`
--

INSERT INTO `mitglieder` (`mitgliedid`, `globalid`, `eintritt`, `austritt`) VALUES
(1, '4ced38bd51d2a@test.prauscher', '2010-11-24', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mitgliederrevisions`
--

CREATE TABLE IF NOT EXISTS `mitgliederrevisions` (
  `revisionid` int(10) unsigned NOT NULL auto_increment,
  `globaleid` varchar(50) NOT NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `userid` int(10) unsigned default NULL,
  `mitgliedid` int(10) unsigned NOT NULL,
  `mitgliedschaftid` int(10) unsigned NOT NULL,
  `gliederungsid` int(10) unsigned default NULL,
  `geloescht` tinyint(1) NOT NULL default '0',
  `mitglied_piraten` tinyint(1) NOT NULL,
  `verteiler_eingetragen` tinyint(1) NOT NULL default '0',
  `beitrag` double unsigned NOT NULL,
  `natpersonid` int(10) unsigned default NULL,
  `jurpersonid` int(10) unsigned default NULL,
  `kontaktid` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`revisionid`),
  UNIQUE KEY `globaleid` (`globaleid`),
  KEY `mitgliedid` (`mitgliedid`),
  KEY `userid` (`userid`),
  KEY `mitgliedschaftid` (`mitgliedschaftid`),
  KEY `gliederungsid` (`gliederungsid`),
  KEY `natpersonid` (`natpersonid`),
  KEY `jurpersonid` (`jurpersonid`),
  KEY `kontaktid` (`kontaktid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `mitgliederrevisions`
--

INSERT INTO `mitgliederrevisions` (`revisionid`, `globaleid`, `timestamp`, `userid`, `mitgliedid`, `mitgliedschaftid`, `gliederungsid`, `geloescht`, `mitglied_piraten`, `verteiler_eingetragen`, `beitrag`, 
`natpersonid`, `jurpersonid`, `kontaktid`) VALUES
(1, '4ced38bd51d2a@test.prauscher', '2010-11-24 17:09:33', 1, 1, 1, 1, 0, 0, 0, 42.23, 1, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `mitgliedschaften`
--

CREATE TABLE IF NOT EXISTS `mitgliedschaften` (
  `mitgliedschaftid` int(10) unsigned NOT NULL auto_increment,
  `label` varchar(25) NOT NULL,
  `description` text,
  `defaultbeitrag` double unsigned default NULL,
  `defaultcreatemail` int(10) unsigned default NULL,
  PRIMARY KEY  (`mitgliedschaftid`),
  KEY `defaultcreatemail` (`defaultcreatemail`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `mitgliedschaften`
--

INSERT INTO `mitgliedschaften` (`mitgliedschaftid`, `label`, `description`, `defaultbeitrag`, `defaultcreatemail`) VALUES
(1, 'Ordentliches Mitglied', NULL, 12, NULL),
(2, 'Fördermitglied', NULL, 12, NULL),
(3, 'Ehrenmitglied', NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `natperson`
--

CREATE TABLE IF NOT EXISTS `natperson` (
  `natpersonid` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(30) NOT NULL,
  `vorname` varchar(35) NOT NULL,
  `geburtsdatum` date NOT NULL,
  `nationalitaet` varchar(15) NOT NULL,
  PRIMARY KEY  (`natpersonid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `natperson`
--

INSERT INTO `natperson` (`natpersonid`, `name`, `vorname`, `geburtsdatum`, `nationalitaet`) VALUES
(1, 'Berndsen', 'Bernd', '1990-05-01', 'Deutsch');

-- --------------------------------------------------------

--
-- Table structure for table `orte`
--

CREATE TABLE IF NOT EXISTS `orte` (
  `ortid` int(10) unsigned NOT NULL auto_increment,
  `plz` varchar(5) NOT NULL,
  `label` varchar(30) NOT NULL,
  `stateid` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`ortid`),
  KEY `stateid` (`stateid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `orte`
--

INSERT INTO `orte` (`ortid`, `plz`, `label`, `stateid`) VALUES
(1, '12345', 'Troll HART', 3);

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE IF NOT EXISTS `permissions` (
  `permissionid` int(10) unsigned NOT NULL auto_increment,
  `label` varchar(20) NOT NULL,
  `description` text,
  PRIMARY KEY  (`permissionid`),
  UNIQUE KEY `label` (`label`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`permissionid`, `label`, `description`) VALUES
(1, 'users_show', NULL),
(2, 'users_modify', NULL),
(3, 'users_create', NULL),
(4, 'roles_show', NULL),
(5, 'roles_modify', NULL),
(6, 'roles_create', NULL),
(7, 'users_delete', NULL),
(8, 'roles_delete', NULL),
(9, 'mitglieder_show', NULL),
(10, 'mitglieder_modify', NULL),
(11, 'mitglieder_create', NULL),
(12, 'mitglieder_delete', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `rolepermissions`
--

CREATE TABLE IF NOT EXISTS `rolepermissions` (
  `roleid` int(10) unsigned NOT NULL,
  `permissionid` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`roleid`,`permissionid`),
  KEY `permissionid` (`permissionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rolepermissions`
--

INSERT INTO `rolepermissions` (`roleid`, `permissionid`) VALUES
(6, 1),
(7, 1),
(7, 2),
(7, 3),
(6, 4),
(7, 4),
(7, 5),
(7, 6),
(7, 7),
(7, 8),
(7, 9),
(7, 10),
(7, 11),
(7, 12);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `roleid` int(10) unsigned NOT NULL auto_increment,
  `label` varchar(20) NOT NULL,
  `description` text,
  PRIMARY KEY  (`roleid`),
  UNIQUE KEY `label` (`label`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`roleid`, `label`, `description`) VALUES
(6, 'User', 'Grundlegende Rechte fÃ¼r alle Benutzer'),
(7, 'Administrator', 'Systemadministratoren zur Verwaltung von Zugriffsrechten');

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE IF NOT EXISTS `states` (
  `stateid` int(10) unsigned NOT NULL auto_increment,
  `label` varchar(25) NOT NULL,
  `countryid` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`stateid`),
  KEY `countryid` (`countryid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`stateid`, `label`, `countryid`) VALUES
(1, 'Baden-Württemberg', 1),
(2, 'Bayern', 1),
(3, 'Berlin', 1),
(4, 'Brandenburg', 1),
(5, 'Bremen', 1),
(6, 'Hamburg', 1),
(7, 'Hessen', 1),
(8, 'Mecklenburg-Vorpommern', 1),
(9, 'Niedersachsen', 1),
(10, 'Nordrhein-Westfalen', 1),
(11, 'Rheinland-Pfalz', 1),
(12, 'Saarland', 1),
(13, 'Sachsen', 1),
(14, 'Sachsen-Anhalt', 1),
(15, 'Schleswig-Holstein', 1),
(16, 'Thüringen', 1);

-- --------------------------------------------------------

--
-- Table structure for table `userroles`
--

CREATE TABLE IF NOT EXISTS `userroles` (
  `userid` int(10) unsigned NOT NULL,
  `roleid` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`userid`,`roleid`),
  KEY `roleid` (`roleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `userroles`
--

INSERT INTO `userroles` (`userid`, `roleid`) VALUES
(1, 6),
(1, 7);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `userid` int(10) unsigned NOT NULL auto_increment,
  `username` varchar(20) NOT NULL,
  `password` char(64) NOT NULL,
  PRIMARY KEY  (`userid`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `username`, `password`) VALUES
(1, 'demo', '2a97516c354b68848cdbd8f54a226a0a55b21ed138e207ad6c5cbb9c00aa5aea');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `mailtemplateattachments`
--
ALTER TABLE `mailtemplateattachments`
  ADD CONSTRAINT `mailtemplateattachments_ibfk_1` FOREIGN KEY (`templateid`) REFERENCES `mailtemplates` (`templateid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `mailtemplateattachments_ibfk_2` FOREIGN KEY (`attachmentid`) REFERENCES `mailattachments` (`attachmentid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `mailtemplateheaders`
--
ALTER TABLE `mailtemplateheaders`
  ADD CONSTRAINT `mailtemplateheaders_ibfk_1` FOREIGN KEY (`templateid`) REFERENCES `mailtemplates` (`templateid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `mailtemplateheaders_ibfk_2` FOREIGN KEY (`headerid`) REFERENCES `mailheaders` (`headerid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `mitgliederrevisions`
--
ALTER TABLE `mitgliederrevisions`
  ADD CONSTRAINT `mitgliederrevisions_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`userid`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `mitgliederrevisions_ibfk_2` FOREIGN KEY (`mitgliedid`) REFERENCES `mitglieder` (`mitgliedid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `mitgliederrevisions_ibfk_3` FOREIGN KEY (`gliederungsid`) REFERENCES `gliederungen` (`gliederungsid`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `mitgliederrevisions_ibfk_5` FOREIGN KEY (`mitgliedschaftid`) REFERENCES `mitgliedschaften` (`mitgliedschaftid`),
  ADD CONSTRAINT `mitgliederrevisions_ibfk_8` FOREIGN KEY (`kontaktid`) REFERENCES `kontakte` (`kontaktid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `mitgliedschaften`
--
ALTER TABLE `mitgliedschaften`
  ADD CONSTRAINT `mitgliedschaften_ibfk_1` FOREIGN KEY (`defaultcreatemail`) REFERENCES `mailtemplates` (`templateid`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `orte`
--
ALTER TABLE `orte`
  ADD CONSTRAINT `orte_ibfk_1` FOREIGN KEY (`stateid`) REFERENCES `states` (`stateid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rolepermissions`
--
ALTER TABLE `rolepermissions`
  ADD CONSTRAINT `rolepermissions_ibfk_1` FOREIGN KEY (`roleid`) REFERENCES `roles` (`roleid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `rolepermissions_ibfk_2` FOREIGN KEY (`permissionid`) REFERENCES `permissions` (`permissionid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `states`
--
ALTER TABLE `states`
  ADD CONSTRAINT `states_ibfk_1` FOREIGN KEY (`countryid`) REFERENCES `countries` (`countryid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `userroles`
--
ALTER TABLE `userroles`
  ADD CONSTRAINT `userroles_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`userid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `userroles_ibfk_2` FOREIGN KEY (`roleid`) REFERENCES `roles` (`roleid`) ON DELETE CASCADE ON UPDATE CASCADE;

