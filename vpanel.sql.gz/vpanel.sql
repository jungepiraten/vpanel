-- MySQL dump 10.11
--
-- Host: localhost    Database: vpanel_empty
-- ------------------------------------------------------
-- Server version	5.0.51a-24+lenny5-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `beitraege`
--

DROP TABLE IF EXISTS `beitraege`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `beitraege` (
  `beitragid` int(11) unsigned NOT NULL auto_increment,
  `label` varchar(50) NOT NULL,
  `hoehe` double default NULL,
  `mailtemplateid` int(10) unsigned default NULL,
  PRIMARY KEY  (`beitragid`),
  UNIQUE KEY `label` (`label`),
  KEY `mailtemplateid` (`mailtemplateid`),
  CONSTRAINT `beitraege_ibfk_1` FOREIGN KEY (`mailtemplateid`) REFERENCES `mailtemplates` (`templateid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `beitraege`
--

LOCK TABLES `beitraege` WRITE;
/*!40000 ALTER TABLE `beitraege` DISABLE KEYS */;
INSERT INTO `beitraege` VALUES (1,'2012',NULL,1),(2,'Camp 2011',NULL,1);
/*!40000 ALTER TABLE `beitraege` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `countries` (
  `countryid` int(10) unsigned NOT NULL auto_increment,
  `label` varchar(20) NOT NULL,
  PRIMARY KEY  (`countryid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` VALUES (1,'Deutschland');
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dokument`
--

DROP TABLE IF EXISTS `dokument`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `dokument` (
  `dokumentid` int(10) unsigned NOT NULL auto_increment,
  `gliederungid` int(10) unsigned NOT NULL,
  `dokumentkategorieid` int(10) unsigned NOT NULL,
  `dokumentstatusid` int(10) unsigned NOT NULL,
  `identifier` varchar(30) NOT NULL,
  `label` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `data` blob,
  `fileid` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`dokumentid`),
  UNIQUE KEY `fileid` (`fileid`),
  UNIQUE KEY `idKey` (`identifier`),
  KEY `dokumentkategorieid` (`dokumentkategorieid`),
  KEY `dokumentstatusid` (`dokumentstatusid`),
  KEY `gliederungid` (`gliederungid`),
  CONSTRAINT `dokument_ibfk_1` FOREIGN KEY (`dokumentkategorieid`) REFERENCES `dokumentkategorien` (`dokumentkategorieid`),
  CONSTRAINT `dokument_ibfk_2` FOREIGN KEY (`dokumentstatusid`) REFERENCES `dokumentstatus` (`dokumentstatusid`),
  CONSTRAINT `dokument_ibfk_4` FOREIGN KEY (`fileid`) REFERENCES `files` (`fileid`),
  CONSTRAINT `dokument_ibfk_5` FOREIGN KEY (`gliederungid`) REFERENCES `gliederungen` (`gliederungsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `dokument`
--

LOCK TABLES `dokument` WRITE;
/*!40000 ALTER TABLE `dokument` DISABLE KEYS */;
/*!40000 ALTER TABLE `dokument` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dokumentkategorien`
--

DROP TABLE IF EXISTS `dokumentkategorien`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `dokumentkategorien` (
  `dokumentkategorieid` int(10) unsigned NOT NULL auto_increment,
  `label` varchar(50) NOT NULL,
  PRIMARY KEY  (`dokumentkategorieid`),
  UNIQUE KEY `label` (`label`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `dokumentkategorien`
--

LOCK TABLES `dokumentkategorien` WRITE;
/*!40000 ALTER TABLE `dokumentkategorien` DISABLE KEYS */;
INSERT INTO `dokumentkategorien` VALUES (1,'Briefverkehr ausgehend'),(2,'Briefverkehr eingehend'),(3,'Datenschutzerklärung'),(4,'Jahresabschlussbericht'),(5,'Kostenrückerstattung'),(7,'Mitgliedsantrag'),(9,'Protokolle der Bundesmitgliederversammlung'),(8,'Protokolle des Bundesvorstands'),(6,'Rechnung'),(10,'Werbung');
/*!40000 ALTER TABLE `dokumentkategorien` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dokumentnotifies`
--

DROP TABLE IF EXISTS `dokumentnotifies`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `dokumentnotifies` (
  `dokumentnotifyid` int(10) unsigned NOT NULL auto_increment,
  `gliederungid` int(10) unsigned default NULL,
  `dokumentkategorieid` int(10) unsigned default NULL,
  `dokumentstatusid` int(10) unsigned default NULL,
  `emailid` int(10) unsigned default NULL,
  PRIMARY KEY  (`dokumentnotifyid`),
  KEY `dokumentkategoriestatus` (`dokumentkategorieid`,`dokumentstatusid`),
  KEY `dokumentkategorieid` (`dokumentkategorieid`),
  KEY `dokumentstatusid` (`dokumentstatusid`),
  KEY `emailid` (`emailid`),
  KEY `gliederungid` (`gliederungid`),
  CONSTRAINT `dokumentnotifies_ibfk_3` FOREIGN KEY (`dokumentkategorieid`) REFERENCES `dokumentkategorien` (`dokumentkategorieid`),
  CONSTRAINT `dokumentnotifies_ibfk_4` FOREIGN KEY (`dokumentstatusid`) REFERENCES `dokumentstatus` (`dokumentstatusid`),
  CONSTRAINT `dokumentnotifies_ibfk_5` FOREIGN KEY (`emailid`) REFERENCES `emails` (`emailid`),
  CONSTRAINT `dokumentnotifies_ibfk_6` FOREIGN KEY (`gliederungid`) REFERENCES `gliederungen` (`gliederungsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `dokumentnotifies`
--

LOCK TABLES `dokumentnotifies` WRITE;
/*!40000 ALTER TABLE `dokumentnotifies` DISABLE KEYS */;
/*!40000 ALTER TABLE `dokumentnotifies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dokumentnotizen`
--

DROP TABLE IF EXISTS `dokumentnotizen`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `dokumentnotizen` (
  `dokumentnotizid` int(10) unsigned NOT NULL auto_increment,
  `dokumentid` int(10) unsigned NOT NULL,
  `author` int(10) unsigned NOT NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `nextState` int(10) unsigned default NULL,
  `nextKategorie` int(10) unsigned default NULL,
  `kommentar` text NOT NULL,
  PRIMARY KEY  (`dokumentnotizid`),
  KEY `dokumentid` (`dokumentid`),
  KEY `author` (`author`),
  KEY `nextState` (`nextState`),
  KEY `nextKategorie` (`nextKategorie`),
  CONSTRAINT `dokumentnotizen_ibfk_1` FOREIGN KEY (`dokumentid`) REFERENCES `dokument` (`dokumentid`),
  CONSTRAINT `dokumentnotizen_ibfk_2` FOREIGN KEY (`author`) REFERENCES `users` (`userid`),
  CONSTRAINT `dokumentnotizen_ibfk_3` FOREIGN KEY (`nextState`) REFERENCES `dokumentstatus` (`dokumentstatusid`),
  CONSTRAINT `dokumentnotizen_ibfk_4` FOREIGN KEY (`nextKategorie`) REFERENCES `dokumentkategorien` (`dokumentkategorieid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `dokumentnotizen`
--

LOCK TABLES `dokumentnotizen` WRITE;
/*!40000 ALTER TABLE `dokumentnotizen` DISABLE KEYS */;
/*!40000 ALTER TABLE `dokumentnotizen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dokumentstatus`
--

DROP TABLE IF EXISTS `dokumentstatus`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `dokumentstatus` (
  `dokumentstatusid` int(10) unsigned NOT NULL auto_increment,
  `label` varchar(50) NOT NULL,
  PRIMARY KEY  (`dokumentstatusid`),
  UNIQUE KEY `label` (`label`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `dokumentstatus`
--

LOCK TABLES `dokumentstatus` WRITE;
/*!40000 ALTER TABLE `dokumentstatus` DISABLE KEYS */;
INSERT INTO `dokumentstatus` VALUES (2,'Archiviert'),(1,'Offen');
/*!40000 ALTER TABLE `dokumentstatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `emailbounces`
--

DROP TABLE IF EXISTS `emailbounces`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `emailbounces` (
  `bounceid` int(10) unsigned NOT NULL auto_increment,
  `emailid` int(10) unsigned NOT NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `message` text NOT NULL,
  PRIMARY KEY  (`bounceid`),
  KEY `emailid` (`emailid`),
  CONSTRAINT `emailbounces_ibfk_1` FOREIGN KEY (`emailid`) REFERENCES `emails` (`emailid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `emailbounces`
--

LOCK TABLES `emailbounces` WRITE;
/*!40000 ALTER TABLE `emailbounces` DISABLE KEYS */;
/*!40000 ALTER TABLE `emailbounces` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `emails`
--

DROP TABLE IF EXISTS `emails`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `emails` (
  `emailid` int(10) unsigned NOT NULL auto_increment,
  `email` varchar(100) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`emailid`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `emails`
--

LOCK TABLES `emails` WRITE;
/*!40000 ALTER TABLE `emails` DISABLE KEYS */;
/*!40000 ALTER TABLE `emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `files` (
  `fileid` int(10) unsigned NOT NULL auto_increment,
  `filename` varchar(50) NOT NULL,
  `exportfilename` varchar(50) NOT NULL,
  `mimetype` varchar(25) NOT NULL default 'application/octet-stream',
  PRIMARY KEY  (`fileid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `files`
--

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gliederungen`
--

DROP TABLE IF EXISTS `gliederungen`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `gliederungen` (
  `gliederungsid` int(10) unsigned NOT NULL auto_increment,
  `label` varchar(50) NOT NULL,
  `parentid` int(10) unsigned default NULL,
  PRIMARY KEY  (`gliederungsid`),
  KEY `parentid` (`parentid`),
  CONSTRAINT `gliederungen_ibfk_1` FOREIGN KEY (`parentid`) REFERENCES `gliederungen` (`gliederungsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `gliederungen`
--

LOCK TABLES `gliederungen` WRITE;
/*!40000 ALTER TABLE `gliederungen` DISABLE KEYS */;
INSERT INTO `gliederungen` VALUES (1,'Bundesverband',NULL);
/*!40000 ALTER TABLE `gliederungen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jurperson`
--

DROP TABLE IF EXISTS `jurperson`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `jurperson` (
  `jurpersonid` int(10) unsigned NOT NULL auto_increment,
  `label` varchar(50) NOT NULL,
  PRIMARY KEY  (`jurpersonid`),
  UNIQUE KEY `label` (`label`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `jurperson`
--

LOCK TABLES `jurperson` WRITE;
/*!40000 ALTER TABLE `jurperson` DISABLE KEYS */;
/*!40000 ALTER TABLE `jurperson` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kontakte`
--

DROP TABLE IF EXISTS `kontakte`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `kontakte` (
  `kontaktid` int(10) unsigned NOT NULL auto_increment,
  `adresszusatz` varchar(70) NOT NULL,
  `strasse` varchar(40) NOT NULL,
  `hausnummer` varchar(10) NOT NULL,
  `ortid` int(10) unsigned NOT NULL,
  `telefonnummer` varchar(15) NOT NULL,
  `handynummer` varchar(15) NOT NULL,
  `emailid` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`kontaktid`),
  KEY `ortid` (`ortid`),
  KEY `emailid` (`emailid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `kontakte`
--

LOCK TABLES `kontakte` WRITE;
/*!40000 ALTER TABLE `kontakte` DISABLE KEYS */;
/*!40000 ALTER TABLE `kontakte` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mailtemplateattachments`
--

DROP TABLE IF EXISTS `mailtemplateattachments`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `mailtemplateattachments` (
  `templateid` int(10) unsigned NOT NULL,
  `fileid` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`templateid`,`fileid`),
  KEY `templateid` (`templateid`),
  KEY `fileid` (`fileid`),
  CONSTRAINT `mailtemplateattachments_ibfk_1` FOREIGN KEY (`templateid`) REFERENCES `mailtemplates` (`templateid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `mailtemplateattachments_ibfk_2` FOREIGN KEY (`fileid`) REFERENCES `files` (`fileid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `mailtemplateattachments`
--

LOCK TABLES `mailtemplateattachments` WRITE;
/*!40000 ALTER TABLE `mailtemplateattachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `mailtemplateattachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mailtemplateheaders`
--

DROP TABLE IF EXISTS `mailtemplateheaders`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `mailtemplateheaders` (
  `templateid` int(10) unsigned NOT NULL,
  `field` varchar(30) NOT NULL,
  `value` varchar(70) NOT NULL,
  PRIMARY KEY  (`templateid`,`field`),
  CONSTRAINT `mailtemplateheaders_ibfk_1` FOREIGN KEY (`templateid`) REFERENCES `mailtemplates` (`templateid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `mailtemplateheaders`
--

LOCK TABLES `mailtemplateheaders` WRITE;
/*!40000 ALTER TABLE `mailtemplateheaders` DISABLE KEYS */;
INSERT INTO `mailtemplateheaders` VALUES (1,'Organisation','Junge Piraten'),(1,'Subject','Willkommen bei den Jungen Piraten');
/*!40000 ALTER TABLE `mailtemplateheaders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mailtemplates`
--

DROP TABLE IF EXISTS `mailtemplates`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `mailtemplates` (
  `templateid` int(10) unsigned NOT NULL auto_increment,
  `gliederungid` int(10) unsigned NOT NULL,
  `label` varchar(50) NOT NULL,
  `body` text NOT NULL,
  PRIMARY KEY  (`templateid`),
  UNIQUE KEY `label` (`label`),
  KEY `gliederungid` (`gliederungid`),
  CONSTRAINT `mailtemplates_ibfk_1` FOREIGN KEY (`gliederungid`) REFERENCES `gliederungen` (`gliederungsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `mailtemplates`
--

LOCK TABLES `mailtemplates` WRITE;
/*!40000 ALTER TABLE `mailtemplates` DISABLE KEYS */;
INSERT INTO `mailtemplates` VALUES (1,1,'Allgemeine Willkommensmail','Ahoi,\r\n\r\nwillkommen bei den Jungen Piraten. Dein Mitgliedsbeitrag als {MITGLIEDSCHAFT} liegt bei {BEITRAG} €.\r\nDies ist die Begrüßungsmail für normale Mitglieder.\r\n\r\n{BEZEICHNUNG}\r\n{STRASSE} {HAUSNUMMER}\r\n{PLZ} {ORT}\r\n{COUNTRY}\r\n\r\nfoobar,');
/*!40000 ALTER TABLE `mailtemplates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mitglieddokument`
--

DROP TABLE IF EXISTS `mitglieddokument`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `mitglieddokument` (
  `mitgliedid` int(10) unsigned NOT NULL,
  `dokumentid` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`mitgliedid`,`dokumentid`),
  KEY `mitgliedid` (`mitgliedid`),
  KEY `dokumentid` (`dokumentid`),
  CONSTRAINT `mitglieddokument_ibfk_1` FOREIGN KEY (`mitgliedid`) REFERENCES `mitglieder` (`mitgliedid`),
  CONSTRAINT `mitglieddokument_ibfk_2` FOREIGN KEY (`dokumentid`) REFERENCES `dokument` (`dokumentid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `mitglieddokument`
--

LOCK TABLES `mitglieddokument` WRITE;
/*!40000 ALTER TABLE `mitglieddokument` DISABLE KEYS */;
/*!40000 ALTER TABLE `mitglieddokument` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mitglieder`
--

DROP TABLE IF EXISTS `mitglieder`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `mitglieder` (
  `mitgliedid` int(10) unsigned NOT NULL auto_increment,
  `globalid` varchar(50) NOT NULL,
  `eintritt` date NOT NULL,
  `austritt` date default NULL,
  PRIMARY KEY  (`mitgliedid`),
  UNIQUE KEY `globalid` (`globalid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `mitglieder`
--

LOCK TABLES `mitglieder` WRITE;
/*!40000 ALTER TABLE `mitglieder` DISABLE KEYS */;
/*!40000 ALTER TABLE `mitglieder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mitgliederbeitrag`
--

DROP TABLE IF EXISTS `mitgliederbeitrag`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `mitgliederbeitrag` (
  `mitgliederbeitragid` int(10) unsigned NOT NULL auto_increment,
  `mitgliedid` int(10) unsigned NOT NULL,
  `beitragid` int(10) unsigned NOT NULL,
  `hoehe` double NOT NULL,
  PRIMARY KEY  (`mitgliederbeitragid`),
  KEY `mitgliedid` (`mitgliedid`),
  KEY `beitragid` (`beitragid`),
  CONSTRAINT `mitgliederbeitrag_ibfk_1` FOREIGN KEY (`mitgliedid`) REFERENCES `mitglieder` (`mitgliedid`),
  CONSTRAINT `mitgliederbeitrag_ibfk_2` FOREIGN KEY (`beitragid`) REFERENCES `beitraege` (`beitragid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `mitgliederbeitrag`
--

LOCK TABLES `mitgliederbeitrag` WRITE;
/*!40000 ALTER TABLE `mitgliederbeitrag` DISABLE KEYS */;
/*!40000 ALTER TABLE `mitgliederbeitrag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mitgliederbeitragbuchung`
--

DROP TABLE IF EXISTS `mitgliederbeitragbuchung`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `mitgliederbeitragbuchung` (
  `buchungid` int(10) unsigned NOT NULL auto_increment,
  `beitragid` int(10) unsigned NOT NULL,
  `gliederungid` int(10) unsigned NOT NULL,
  `userid` int(10) unsigned default NULL,
  `timestamp` date default NULL,
  `vermerk` text NOT NULL,
  `hoehe` double NOT NULL,
  PRIMARY KEY  (`buchungid`),
  KEY `gliederungid` (`gliederungid`),
  KEY `beitragid` (`beitragid`),
  KEY `userid` (`userid`),
  CONSTRAINT `mitgliederbeitragbuchung_ibfk_3` FOREIGN KEY (`gliederungid`) REFERENCES `gliederungen` (`gliederungsid`),
  CONSTRAINT `mitgliederbeitragbuchung_ibfk_4` FOREIGN KEY (`beitragid`) REFERENCES `mitgliederbeitrag` (`mitgliederbeitragid`),
  CONSTRAINT `mitgliederbeitragbuchung_ibfk_5` FOREIGN KEY (`userid`) REFERENCES `users` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `mitgliederbeitragbuchung`
--

LOCK TABLES `mitgliederbeitragbuchung` WRITE;
/*!40000 ALTER TABLE `mitgliederbeitragbuchung` DISABLE KEYS */;
/*!40000 ALTER TABLE `mitgliederbeitragbuchung` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mitgliederflags`
--

DROP TABLE IF EXISTS `mitgliederflags`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `mitgliederflags` (
  `flagid` int(10) unsigned NOT NULL auto_increment,
  `label` varchar(50) NOT NULL,
  PRIMARY KEY  (`flagid`),
  UNIQUE KEY `label` (`label`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `mitgliederflags`
--

LOCK TABLES `mitgliederflags` WRITE;
/*!40000 ALTER TABLE `mitgliederflags` DISABLE KEYS */;
INSERT INTO `mitgliederflags` VALUES (1,'Mitglied PP'),(3,'Testelement'),(2,'Verteiler eingetragen');
/*!40000 ALTER TABLE `mitgliederflags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mitgliedernotizen`
--

DROP TABLE IF EXISTS `mitgliedernotizen`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `mitgliedernotizen` (
  `mitgliednotizid` int(10) unsigned NOT NULL auto_increment,
  `mitgliedid` int(10) unsigned NOT NULL,
  `author` int(10) unsigned default NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `kommentar` text NOT NULL,
  PRIMARY KEY  (`mitgliednotizid`),
  KEY `author` (`author`),
  KEY `mitgliedid` (`mitgliedid`),
  CONSTRAINT `mitgliedernotizen_ibfk_1` FOREIGN KEY (`mitgliedid`) REFERENCES `mitglieder` (`mitgliedid`),
  CONSTRAINT `mitgliedernotizen_ibfk_2` FOREIGN KEY (`author`) REFERENCES `users` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `mitgliedernotizen`
--

LOCK TABLES `mitgliedernotizen` WRITE;
/*!40000 ALTER TABLE `mitgliedernotizen` DISABLE KEYS */;
/*!40000 ALTER TABLE `mitgliedernotizen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mitgliederrevisionflags`
--

DROP TABLE IF EXISTS `mitgliederrevisionflags`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `mitgliederrevisionflags` (
  `revisionid` int(10) unsigned NOT NULL,
  `flagid` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`revisionid`,`flagid`),
  KEY `flagid` (`flagid`),
  CONSTRAINT `mitgliederrevisionflags_ibfk_1` FOREIGN KEY (`revisionid`) REFERENCES `mitgliederrevisions` (`revisionid`),
  CONSTRAINT `mitgliederrevisionflags_ibfk_2` FOREIGN KEY (`flagid`) REFERENCES `mitgliederflags` (`flagid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `mitgliederrevisionflags`
--

LOCK TABLES `mitgliederrevisionflags` WRITE;
/*!40000 ALTER TABLE `mitgliederrevisionflags` DISABLE KEYS */;
/*!40000 ALTER TABLE `mitgliederrevisionflags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mitgliederrevisions`
--

DROP TABLE IF EXISTS `mitgliederrevisions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `mitgliederrevisions` (
  `revisionid` int(10) unsigned NOT NULL auto_increment,
  `globaleid` varchar(50) NOT NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `userid` int(10) unsigned default NULL,
  `mitgliedid` int(10) unsigned NOT NULL,
  `mitgliedschaftid` int(10) unsigned NOT NULL,
  `gliederungsid` int(10) unsigned default NULL,
  `geloescht` tinyint(1) NOT NULL default '0',
  `beitrag` double unsigned NOT NULL,
  `natpersonid` int(10) unsigned default NULL,
  `jurpersonid` int(10) unsigned default NULL,
  `kontaktid` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`revisionid`),
  UNIQUE KEY `globaleid` (`globaleid`),
  KEY `mitgliedid` (`mitgliedid`),
  KEY `userid` (`userid`),
  KEY `mitgliedschaftid` (`mitgliedschaftid`),
  KEY `gliederungsid` (`gliederungsid`),
  KEY `natpersonid` (`natpersonid`),
  KEY `jurpersonid` (`jurpersonid`),
  KEY `kontaktid` (`kontaktid`),
  CONSTRAINT `mitgliederrevisions_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`userid`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `mitgliederrevisions_ibfk_2` FOREIGN KEY (`mitgliedid`) REFERENCES `mitglieder` (`mitgliedid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `mitgliederrevisions_ibfk_3` FOREIGN KEY (`gliederungsid`) REFERENCES `gliederungen` (`gliederungsid`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `mitgliederrevisions_ibfk_5` FOREIGN KEY (`mitgliedschaftid`) REFERENCES `mitgliedschaften` (`mitgliedschaftid`),
  CONSTRAINT `mitgliederrevisions_ibfk_8` FOREIGN KEY (`kontaktid`) REFERENCES `kontakte` (`kontaktid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `mitgliederrevisions`
--

LOCK TABLES `mitgliederrevisions` WRITE;
/*!40000 ALTER TABLE `mitgliederrevisions` DISABLE KEYS */;
/*!40000 ALTER TABLE `mitgliederrevisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mitgliederrevisiontextfields`
--

DROP TABLE IF EXISTS `mitgliederrevisiontextfields`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `mitgliederrevisiontextfields` (
  `revisionid` int(10) unsigned NOT NULL,
  `textfieldid` int(10) unsigned NOT NULL,
  `value` text,
  PRIMARY KEY  (`revisionid`,`textfieldid`),
  KEY `revisionid` (`revisionid`),
  KEY `textfieldid` (`textfieldid`),
  CONSTRAINT `mitgliederrevisiontextfields_ibfk_1` FOREIGN KEY (`revisionid`) REFERENCES `mitgliederrevisions` (`revisionid`),
  CONSTRAINT `mitgliederrevisiontextfields_ibfk_2` FOREIGN KEY (`textfieldid`) REFERENCES `mitgliedertextfields` (`textfieldid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `mitgliederrevisiontextfields`
--

LOCK TABLES `mitgliederrevisiontextfields` WRITE;
/*!40000 ALTER TABLE `mitgliederrevisiontextfields` DISABLE KEYS */;
/*!40000 ALTER TABLE `mitgliederrevisiontextfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mitgliedertextfields`
--

DROP TABLE IF EXISTS `mitgliedertextfields`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `mitgliedertextfields` (
  `textfieldid` int(10) unsigned NOT NULL auto_increment,
  `label` varchar(50) NOT NULL,
  PRIMARY KEY  (`textfieldid`),
  UNIQUE KEY `label` (`label`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `mitgliedertextfields`
--

LOCK TABLES `mitgliedertextfields` WRITE;
/*!40000 ALTER TABLE `mitgliedertextfields` DISABLE KEYS */;
INSERT INTO `mitgliedertextfields` VALUES (1,'Beispielfeld');
/*!40000 ALTER TABLE `mitgliedertextfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mitgliedschaften`
--

DROP TABLE IF EXISTS `mitgliedschaften`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `mitgliedschaften` (
  `mitgliedschaftid` int(10) unsigned NOT NULL auto_increment,
  `label` varchar(50) NOT NULL,
  `description` text,
  PRIMARY KEY  (`mitgliedschaftid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `mitgliedschaften`
--

LOCK TABLES `mitgliedschaften` WRITE;
/*!40000 ALTER TABLE `mitgliedschaften` DISABLE KEYS */;
INSERT INTO `mitgliedschaften` VALUES (1,'Ordentliches Mitglied',NULL),(2,'Fördermitglied',NULL),(3,'Ehrenmitglied',NULL);
/*!40000 ALTER TABLE `mitgliedschaften` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mitgliedtemplates`
--

DROP TABLE IF EXISTS `mitgliedtemplates`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `mitgliedtemplates` (
  `mitgliedtemplateid` int(10) unsigned NOT NULL auto_increment,
  `label` varchar(70) NOT NULL,
  `gliederungid` int(10) unsigned default NULL,
  `mitgliedschaftid` int(10) unsigned default NULL,
  `beitrag` double default NULL,
  `createmail` int(10) unsigned default NULL,
  PRIMARY KEY  (`mitgliedtemplateid`),
  UNIQUE KEY `label` (`label`),
  KEY `createmail` (`createmail`),
  KEY `gliederungid` (`gliederungid`),
  KEY `mitgliedschaftid` (`mitgliedschaftid`),
  CONSTRAINT `mitgliedtemplates_ibfk_1` FOREIGN KEY (`gliederungid`) REFERENCES `gliederungen` (`gliederungsid`),
  CONSTRAINT `mitgliedtemplates_ibfk_2` FOREIGN KEY (`mitgliedschaftid`) REFERENCES `mitgliedschaften` (`mitgliedschaftid`),
  CONSTRAINT `mitgliedtemplates_ibfk_3` FOREIGN KEY (`createmail`) REFERENCES `mailtemplates` (`templateid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `mitgliedtemplates`
--

LOCK TABLES `mitgliedtemplates` WRITE;
/*!40000 ALTER TABLE `mitgliedtemplates` DISABLE KEYS */;
INSERT INTO `mitgliedtemplates` VALUES (1,'Mitglied 1',1,1,12,1);
/*!40000 ALTER TABLE `mitgliedtemplates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `natperson`
--

DROP TABLE IF EXISTS `natperson`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `natperson` (
  `natpersonid` int(10) unsigned NOT NULL auto_increment,
  `anrede` varchar(15) NOT NULL,
  `name` varchar(30) NOT NULL,
  `vorname` varchar(35) NOT NULL,
  `geburtsdatum` date NOT NULL,
  `nationalitaet` varchar(20) NOT NULL,
  PRIMARY KEY  (`natpersonid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `natperson`
--

LOCK TABLES `natperson` WRITE;
/*!40000 ALTER TABLE `natperson` DISABLE KEYS */;
/*!40000 ALTER TABLE `natperson` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orte`
--

DROP TABLE IF EXISTS `orte`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `orte` (
  `ortid` int(10) unsigned NOT NULL auto_increment,
  `plz` varchar(5) NOT NULL,
  `label` varchar(30) NOT NULL,
  `latitude` double default NULL,
  `longitude` double default NULL,
  `stateid` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`ortid`),
  KEY `stateid` (`stateid`),
  CONSTRAINT `orte_ibfk_1` FOREIGN KEY (`stateid`) REFERENCES `states` (`stateid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `orte`
--

LOCK TABLES `orte` WRITE;
/*!40000 ALTER TABLE `orte` DISABLE KEYS */;
/*!40000 ALTER TABLE `orte` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `permissions` (
  `permissionid` int(10) unsigned NOT NULL auto_increment,
  `label` varchar(20) NOT NULL,
  `description` text,
  `global` tinyint(1) NOT NULL,
  PRIMARY KEY  (`permissionid`),
  UNIQUE KEY `label` (`label`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'users_show',NULL,1),(2,'users_modify',NULL,1),(3,'users_create',NULL,1),(4,'roles_show',NULL,1),(5,'roles_modify',NULL,1),(6,'roles_create',NULL,1),(7,'users_delete',NULL,1),(8,'roles_delete',NULL,1),(9,'mitglieder_show',NULL,0),(10,'mitglieder_modify',NULL,0),(11,'mitglieder_create',NULL,0),(12,'mitglieder_delete',NULL,0),(13,'statistik_show',NULL,0),(14,'mailtemplates_show',NULL,0),(15,'mailtemplates_create',NULL,0),(16,'mailtemplates_modify',NULL,0),(17,'mailtemplates_delete',NULL,0),(18,'dokumente_show',NULL,0),(19,'dokumente_modify',NULL,0),(20,'dokumente_create',NULL,0),(21,'beitraege_show',NULL,1),(22,'beitraege_create',NULL,1),(23,'beitraege_modify',NULL,1),(24,'beitraege_delete',NULL,1),(25,'mitglieder_moveto',NULL,0),(26,'mitglieder_beitrag',NULL,0),(27,'dokumente_delete',NULL,0);
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `processes`
--

DROP TABLE IF EXISTS `processes`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `processes` (
  `processid` int(10) unsigned NOT NULL auto_increment,
  `userid` int(10) unsigned default NULL,
  `type` varchar(50) NOT NULL,
  `typedata` blob NOT NULL,
  `progress` double NOT NULL,
  `queued` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `started` timestamp NULL default NULL,
  `finished` timestamp NULL default NULL,
  `finishedpage` text NOT NULL,
  PRIMARY KEY  (`processid`),
  KEY `userid` (`userid`),
  CONSTRAINT `processes_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `processes`
--

LOCK TABLES `processes` WRITE;
/*!40000 ALTER TABLE `processes` DISABLE KEYS */;
/*!40000 ALTER TABLE `processes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rolepermissions`
--

DROP TABLE IF EXISTS `rolepermissions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `rolepermissions` (
  `roleid` int(10) unsigned NOT NULL,
  `permissionid` int(10) unsigned NOT NULL,
  `gliederungid` int(10) unsigned default NULL,
  `transitive` tinyint(1) NOT NULL,
  KEY `permissionid` (`permissionid`),
  KEY `gliederungid` (`gliederungid`),
  KEY `roleid` (`roleid`),
  CONSTRAINT `rolepermissions_ibfk_1` FOREIGN KEY (`roleid`) REFERENCES `roles` (`roleid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `rolepermissions_ibfk_2` FOREIGN KEY (`permissionid`) REFERENCES `permissions` (`permissionid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `rolepermissions_ibfk_3` FOREIGN KEY (`gliederungid`) REFERENCES `gliederungen` (`gliederungsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `rolepermissions`
--

LOCK TABLES `rolepermissions` WRITE;
/*!40000 ALTER TABLE `rolepermissions` DISABLE KEYS */;
INSERT INTO `rolepermissions` VALUES (7,1,NULL,0),(7,2,NULL,0),(7,3,NULL,0),(7,4,NULL,0),(7,5,NULL,0),(7,6,NULL,0),(7,7,NULL,0),(7,8,NULL,0);
/*!40000 ALTER TABLE `rolepermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `roles` (
  `roleid` int(10) unsigned NOT NULL auto_increment,
  `label` varchar(50) NOT NULL,
  `description` text,
  PRIMARY KEY  (`roleid`),
  UNIQUE KEY `label` (`label`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (6,'User','Grundlegende Rechte für alle Benutzer'),(7,'Administrator','Systemadministratoren zur Verwaltung von Zugriffsrechten');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sessions` (
  `sessionid` int(10) unsigned NOT NULL auto_increment,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `data` blob NOT NULL,
  PRIMARY KEY  (`sessionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `states`
--

DROP TABLE IF EXISTS `states`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `states` (
  `stateid` int(10) unsigned NOT NULL auto_increment,
  `label` varchar(25) NOT NULL,
  `population` int(10) unsigned default NULL,
  `countryid` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`stateid`),
  KEY `countryid` (`countryid`),
  CONSTRAINT `states_ibfk_1` FOREIGN KEY (`countryid`) REFERENCES `countries` (`countryid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `states`
--

LOCK TABLES `states` WRITE;
/*!40000 ALTER TABLE `states` DISABLE KEYS */;
INSERT INTO `states` VALUES (1,'Baden-Württemberg',10745000,1),(2,'Bayern',12510000,1),(3,'Berlin',3443000,1),(4,'Brandenburg',2512000,1),(5,'Bremen',662000,1),(6,'Hamburg',1774000,1),(7,'Hessen',6062000,1),(8,'Mecklenburg-Vorpommern',1651000,1),(9,'Niedersachsen',7929000,1),(10,'Nordrhein-Westfalen',17873000,1),(11,'Rheinland-Pfalz',4013000,1),(12,'Saarland',1023000,1),(13,'Sachsen',4169000,1),(14,'Sachsen-Anhalt',2356000,1),(15,'Schleswig-Holstein',2832000,1),(16,'Thüringen',2250000,1);
/*!40000 ALTER TABLE `states` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tempfiles`
--

DROP TABLE IF EXISTS `tempfiles`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `tempfiles` (
  `tempfileid` int(10) unsigned NOT NULL auto_increment,
  `userid` int(10) unsigned NOT NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `fileid` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`tempfileid`),
  UNIQUE KEY `fileid` (`fileid`),
  KEY `userid` (`userid`),
  CONSTRAINT `tempfiles_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`userid`),
  CONSTRAINT `tempfiles_ibfk_2` FOREIGN KEY (`fileid`) REFERENCES `files` (`fileid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `tempfiles`
--

LOCK TABLES `tempfiles` WRITE;
/*!40000 ALTER TABLE `tempfiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `tempfiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userroles`
--

DROP TABLE IF EXISTS `userroles`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `userroles` (
  `userid` int(10) unsigned NOT NULL,
  `roleid` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`userid`,`roleid`),
  KEY `roleid` (`roleid`),
  CONSTRAINT `userroles_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`userid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `userroles_ibfk_2` FOREIGN KEY (`roleid`) REFERENCES `roles` (`roleid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `userroles`
--

LOCK TABLES `userroles` WRITE;
/*!40000 ALTER TABLE `userroles` DISABLE KEYS */;
INSERT INTO `userroles` VALUES (1,6),(1,7);
/*!40000 ALTER TABLE `userroles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `users` (
  `userid` int(10) unsigned NOT NULL auto_increment,
  `username` varchar(50) NOT NULL,
  `password` char(64) NOT NULL,
  `passwordsalt` varchar(15) NOT NULL,
  `apikey` varchar(50) default NULL,
  `aktiv` tinyint(1) NOT NULL,
  `defaultgliederungid` int(10) unsigned default NULL,
  `defaultdokumentkategorieid` int(10) unsigned default NULL,
  `defaultdokumentstatusid` int(10) unsigned default NULL,
  PRIMARY KEY  (`userid`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `apikey` (`apikey`),
  KEY `defaultdokumentkategorieid` (`defaultdokumentkategorieid`),
  KEY `defaultdokumentstatusid` (`defaultdokumentstatusid`),
  KEY `defaultgliederungid` (`defaultgliederungid`),
  CONSTRAINT `users_ibfk_3` FOREIGN KEY (`defaultdokumentkategorieid`) REFERENCES `dokumentkategorien` (`dokumentkategorieid`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `users_ibfk_4` FOREIGN KEY (`defaultdokumentstatusid`) REFERENCES `dokumentstatus` (`dokumentstatusid`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','72c5b32d8973e2847d11478b763dd44b4f44e00c6d1c4b3930dc4cd29eede418','9LitK','NULL',1,1,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-06-02 15:51:43
